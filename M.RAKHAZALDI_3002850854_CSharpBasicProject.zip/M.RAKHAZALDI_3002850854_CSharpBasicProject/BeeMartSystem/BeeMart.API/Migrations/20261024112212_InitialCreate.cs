﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BeeMart.API.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "LtPaymentMethod",
                columns: table => new
                {
                    IdPaymentMethod = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MethodName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Stsrc = table.Column<bool>(type: "bit", nullable: false),
                    Datein = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Userin = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Dateup = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Userup = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LtPaymentMethod", x => x.IdPaymentMethod);
                });

            migrationBuilder.CreateTable(
                name: "MsProduct",
                columns: table => new
                {
                    IdProduct = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Weight = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Stock = table.Column<int>(type: "int", nullable: false),
                    Price = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Discount = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Stsrc = table.Column<bool>(type: "bit", nullable: false),
                    Datein = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Userin = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Dateup = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Userup = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MsProduct", x => x.IdProduct);
                });

            migrationBuilder.CreateTable(
                name: "MsUser",
                columns: table => new
                {
                    IdUser = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Username = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FullName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PasswordHash = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Role = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Stsrc = table.Column<bool>(type: "bit", nullable: false),
                    Datein = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Userin = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Dateup = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Userup = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MsUser", x => x.IdUser);
                });

            migrationBuilder.CreateTable(
                name: "TrTransaction",
                columns: table => new
                {
                    IdTransaction = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    InvoiceNo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TransactionDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IdUser = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IdPaymentMethod = table.Column<int>(type: "int", nullable: false),
                    TotalPrice = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Stsrc = table.Column<bool>(type: "bit", nullable: false),
                    Datein = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Userin = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Dateup = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Userup = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TrTransaction", x => x.IdTransaction);
                });

            migrationBuilder.CreateTable(
                name: "TrTransactionDetail",
                columns: table => new
                {
                    IdTransactionDetail = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    IdTransaction = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IdProduct = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Qty = table.Column<int>(type: "int", nullable: false),
                    Price = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Discount = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    SubTotal = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Stsrc = table.Column<bool>(type: "bit", nullable: false),
                    Datein = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Userin = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Dateup = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Userup = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TrTransactionDetail", x => x.IdTransactionDetail);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "LtPaymentMethod");

            migrationBuilder.DropTable(
                name: "MsProduct");

            migrationBuilder.DropTable(
                name: "MsUser");

            migrationBuilder.DropTable(
                name: "TrTransaction");

            migrationBuilder.DropTable(
                name: "TrTransactionDetail");
        }
    }
}
