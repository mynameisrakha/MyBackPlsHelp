﻿using Microsoft.EntityFrameworkCore;
using BeeMart.API.Models;

namespace BeeMart.API.Data
{
    public class BeeMartDbContext : DbContext
    {
        public BeeMartDbContext(DbContextOptions<BeeMartDbContext> options) : base(options) { }

        public DbSet<MsProduct> MsProducts { get; set; }
        public DbSet<MsUser> MsUsers { get; set; }
        public DbSet<LtPaymentMethod> LtPaymentMethods { get; set; }
        public DbSet<TrTransaction> TrTransactions { get; set; }
        public DbSet<TrTransactionDetail> TrTransactionDetails { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Memetakan nama kelas ke nama tabel asli di database SQL Server
            modelBuilder.Entity<MsProduct>().ToTable("MsProduct");
            modelBuilder.Entity<MsUser>().ToTable("MsUser");
            modelBuilder.Entity<LtPaymentMethod>().ToTable("LtPaymentMethod");
            modelBuilder.Entity<TrTransaction>().ToTable("TrTransaction");
            modelBuilder.Entity<TrTransactionDetail>().ToTable("TrTransactionDetail");
        }
    }
}