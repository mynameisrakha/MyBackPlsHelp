using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BeeMart.API.Models;
using BeeMart.API.Data;

[Route("api/[controller]")]
[ApiController]
public class MsProductsController : ControllerBase
{
    private readonly BeeMartDbContext _context;
    public MsProductsController(BeeMartDbContext context)
    {
        _context = context;
    }

        // GET: api/MsProducts/search?keyword=indomie
    // Maksimal 10 data, nama serupa dengan kata kunci
    [HttpGet("search")]
    public async Task<IActionResult> SearchProducts([FromQuery] string keyword)
    {
        if (string.IsNullOrWhiteSpace(keyword))
        {
            return BadRequest(new { message = "Kata kunci pencarian wajib diisi." });
        }

        var result = await _context.MsProducts
            .Where(p => p.Stsrc && p.Name.Contains(keyword))
            .OrderBy(p => p.Name)
            .Take(10)
            .Select(p => new
            {
                idProduct = p.IdProduct,
                name = p.Name,
                weight = p.Weight,
                stock = p.Stock,
                price = p.Price,
                discount = p.Discount
            })
            .ToListAsync();

        return Ok(result);
    }

    // GET: api/MsProduct
    [HttpGet]
    public async Task<ActionResult<IEnumerable<MsProduct>>> GetMsProduct()
    {
        return await _context.MsProducts.ToListAsync();
    }

    // GET: api/MsProduct/5
    [HttpGet("{idproduct}")]
    public async Task<ActionResult<MsProduct>> GetMsProduct(string idproduct)
    {
        var msproduct = await _context.MsProducts.FindAsync(idproduct);

        if (msproduct == null)
        {
            return NotFound();
        }

        return msproduct;
    }

    // PUT: api/MsProduct/5
    // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
    [HttpPut("{idproduct}")]
    public async Task<IActionResult> PutMsProduct(string? idproduct, MsProduct msproduct)
    {
        if (idproduct != msproduct.IdProduct)
        {
            return BadRequest();
        }

        _context.Entry(msproduct).State = EntityState.Modified;

        try
        {
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!MsProductExists(idproduct))
            {
                return NotFound();
            }
            else
            {
                throw;
            }
        }

        return NoContent();
    }

    // POST: api/MsProduct
    // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
    [HttpPost]
    public async Task<ActionResult<MsProduct>> PostMsProduct(MsProduct msproduct)
    {
        _context.MsProducts.Add(msproduct);
        await _context.SaveChangesAsync();

        return CreatedAtAction("GetMsProduct", new { idproduct = msproduct.IdProduct }, msproduct);
    }

    // DELETE: api/MsProduct/5
    [HttpDelete("{idproduct}")]
    public async Task<IActionResult> DeleteMsProduct(string? idproduct)
    {
        var msproduct = await _context.MsProducts.FindAsync(idproduct);
        if (msproduct == null)
        {
            return NotFound();
        }

        _context.MsProducts.Remove(msproduct);
        await _context.SaveChangesAsync();

        return NoContent();
    }

    private bool MsProductExists(string? idproduct)
    {
        return _context.MsProducts.Any(e => e.IdProduct == idproduct);
    }
}
