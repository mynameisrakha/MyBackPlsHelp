using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BeeMart.API.Models;
using BeeMart.API.Data;

[Route("api/[controller]")]
[ApiController]
public class LtPaymentMethodsController : ControllerBase
{
    private readonly BeeMartDbContext _context;
    public LtPaymentMethodsController(BeeMartDbContext context)
    {
        _context = context;
    }

    // GET: api/LtPaymentMethod
    [HttpGet]
    public async Task<ActionResult<IEnumerable<LtPaymentMethod>>> GetLtPaymentMethod()
    {
        return await _context.LtPaymentMethods.ToListAsync();
    }

    // GET: api/LtPaymentMethod/5
    [HttpGet("{idpaymentmethod}")]
    public async Task<ActionResult<LtPaymentMethod>> GetLtPaymentMethod(int idpaymentmethod)
    {
        var ltpaymentmethod = await _context.LtPaymentMethods.FindAsync(idpaymentmethod);

        if (ltpaymentmethod == null)
        {
            return NotFound();
        }

        return ltpaymentmethod;
    }

    // PUT: api/LtPaymentMethod/5
    // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
    [HttpPut("{idpaymentmethod}")]
    public async Task<IActionResult> PutLtPaymentMethod(int? idpaymentmethod, LtPaymentMethod ltpaymentmethod)
    {
        if (idpaymentmethod != ltpaymentmethod.IdPaymentMethod)
        {
            return BadRequest();
        }

        _context.Entry(ltpaymentmethod).State = EntityState.Modified;

        try
        {
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!LtPaymentMethodExists(idpaymentmethod))
            {
                return NotFound();
            }
            else
            {
                throw;
            }
        }

        return NoContent();
    }

    // POST: api/LtPaymentMethod
    // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
    [HttpPost]
    public async Task<ActionResult<LtPaymentMethod>> PostLtPaymentMethod(LtPaymentMethod ltpaymentmethod)
    {
        _context.LtPaymentMethods.Add(ltpaymentmethod);
        await _context.SaveChangesAsync();

        return CreatedAtAction("GetLtPaymentMethod", new { idpaymentmethod = ltpaymentmethod.IdPaymentMethod }, ltpaymentmethod);
    }

    // DELETE: api/LtPaymentMethod/5
    [HttpDelete("{idpaymentmethod}")]
    public async Task<IActionResult> DeleteLtPaymentMethod(int? idpaymentmethod)
    {
        var ltpaymentmethod = await _context.LtPaymentMethods.FindAsync(idpaymentmethod);
        if (ltpaymentmethod == null)
        {
            return NotFound();
        }

        _context.LtPaymentMethods.Remove(ltpaymentmethod);
        await _context.SaveChangesAsync();

        return NoContent();
    }

    private bool LtPaymentMethodExists(int? idpaymentmethod)
    {
        return _context.LtPaymentMethods.Any(e => e.IdPaymentMethod == idpaymentmethod);
    }
}
