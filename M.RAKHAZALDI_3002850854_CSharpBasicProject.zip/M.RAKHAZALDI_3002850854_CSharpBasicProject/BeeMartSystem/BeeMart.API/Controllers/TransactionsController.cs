﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BeeMart.API.Data;
using BeeMart.API.Models;

namespace BeeMart.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransactionsController : ControllerBase
    {
        private readonly BeeMartDbContext _context;

        public TransactionsController(BeeMartDbContext context)
        {
            _context = context;
        }

        // Format: [5 digit userID][ddmmyy][3 digit running number]
        // Running number berurutan per hari untuk semua kasir (sesuai mockup)
        private async Task<string> GenerateInvoiceNoAsync(string idUser)
        {
            string datePart = DateTime.Now.ToString("ddMMyy");

            string userPart = idUser.PadLeft(5, '0');
            if (userPart.Length > 5) userPart = userPart.Substring(userPart.Length - 5);

            var lastInvoice = await _context.TrTransactions
                .Where(t => t.InvoiceNo.Length == 14 && t.InvoiceNo.Substring(5, 6) == datePart)
                .OrderByDescending(t => t.InvoiceNo.Substring(11, 3))
                .Select(t => t.InvoiceNo)
                .FirstOrDefaultAsync();

            int runningNumber = 1;
            if (lastInvoice != null && int.TryParse(lastInvoice.Substring(11, 3), out int lastNum))
            {
                runningNumber = lastNum + 1;
            }

            return userPart + datePart + runningNumber.ToString("D3");
        }

        // GET: api/Transactions/next-invoice?idUser=12345
        [HttpGet("next-invoice")]
        public async Task<IActionResult> GetNextInvoice([FromQuery] string idUser)
        {
            if (string.IsNullOrWhiteSpace(idUser))
            {
                return BadRequest(new { message = "IdUser wajib diisi." });
            }

            var invoiceNo = await GenerateInvoiceNoAsync(idUser);
            return Ok(new { invoiceNo = invoiceNo });
        }

        // POST: api/Transactions/submit
        [HttpPost("submit")]
        public async Task<IActionResult> SubmitTransaction([FromBody] TransactionSubmitDto model)
        {
            if (model == null || model.Details == null || !model.Details.Any())
            {
                return BadRequest(new { message = "Data transaksi atau detail belanjaan kosong." });
            }

            if (string.IsNullOrWhiteSpace(model.IdUser) ||
                !await _context.MsUsers.AnyAsync(u => u.IdUser == model.IdUser))
            {
                return BadRequest(new { message = "User tidak valid." });
            }

            if (!await _context.LtPaymentMethods.AnyAsync(p => p.IdPaymentMethod == model.IdPaymentMethod))
            {
                return BadRequest(new { message = "Metode pembayaran tidak valid." });
            }

            // 1. Generate Invoice No
            string invoiceNo = await GenerateInvoiceNoAsync(model.IdUser);

            // 2. Buat Header & Detail Transaksi
            string transactionId = Guid.NewGuid().ToString();
            decimal totalPrice = 0;
            var transactionDetails = new List<TrTransactionDetail>();

            foreach (var item in model.Details)
            {
                if (item.Qty <= 0)
                {
                    return BadRequest(new { message = "Qty harus lebih dari 0." });
                }

                var product = await _context.MsProducts.FindAsync(item.IdProduct);
                if (product == null)
                {
                    return BadRequest(new { message = $"Produk dengan ID {item.IdProduct} tidak ditemukan." });
                }

                if (item.Qty > product.Stock)
                {
                    return BadRequest(new { message = "Jumlah barang yang dimasukkan melebihi sisa stok." });
                }

                // Kurangi stok produk
                product.Stock -= item.Qty;
                product.Dateup = DateTime.Now;
                product.Userup = model.IdUser;

                decimal subTotal = (product.Price - (product.Price * product.Discount / 100)) * item.Qty;
                totalPrice += subTotal;

                transactionDetails.Add(new TrTransactionDetail
                {
                    IdTransactionDetail = Guid.NewGuid().ToString(),
                    IdTransaction = transactionId,
                    IdProduct = product.IdProduct,
                    Qty = item.Qty,
                    Price = product.Price,
                    Discount = product.Discount,
                    SubTotal = subTotal,
                    Stsrc = true,
                    Datein = DateTime.Now,
                    Userin = model.IdUser
                });
            }

            var transaction = new TrTransaction
            {
                IdTransaction = transactionId,
                InvoiceNo = invoiceNo,
                TransactionDate = DateTime.Now,
                IdUser = model.IdUser,
                IdPaymentMethod = model.IdPaymentMethod,
                TotalPrice = totalPrice,
                Stsrc = true,
                Datein = DateTime.Now,
                Userin = model.IdUser
            };

            _context.TrTransactions.Add(transaction);
            _context.TrTransactionDetails.AddRange(transactionDetails);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Transaksi berhasil disubmit", invoiceNo = invoiceNo });
        }

        // GET: api/Transactions/history?date=2026-09-04&role=Cashier&idUser=US001&page=1
        [HttpGet("history")]
        public async Task<IActionResult> GetTransactionHistory(
            [FromQuery] string date,
            [FromQuery] string role,
            [FromQuery] string idUser,
            [FromQuery] int page = 1)
        {
            if (string.IsNullOrEmpty(date))
            {
                return BadRequest(new { message = "Tanggal wajib dipilih." });
            }

            if (!DateTime.TryParse(date, out DateTime parsedDate))
            {
                return BadRequest(new { message = "Format tanggal tidak valid." });
            }

            if (page < 1) page = 1;

            var baseQuery = _context.TrTransactions.Where(t => t.TransactionDate.Date == parsedDate.Date);

            // Filter hak akses: Kasir hanya melihat transaksinya sendiri, Admin melihat semua
            if (role == "Cashier" || role == "Kasir")
            {
                baseQuery = baseQuery.Where(t => t.IdUser == idUser);
            }

            var totalData = await baseQuery.CountAsync();
            int pageSize = 20; // Maksimal 20 data per halaman
            int totalPages = (int)Math.Ceiling(totalData / (double)pageSize);

            var transactions = await (from t in baseQuery
                                      join u in _context.MsUsers on t.IdUser equals u.IdUser into userJoin
                                      from u in userJoin.DefaultIfEmpty()
                                      join p in _context.LtPaymentMethods on t.IdPaymentMethod equals p.IdPaymentMethod into payJoin
                                      from p in payJoin.DefaultIfEmpty()
                                      orderby t.TransactionDate ascending
                                      select new
                                      {
                                          idTransaction = t.IdTransaction,
                                          invoiceNo = t.InvoiceNo,
                                          transactionDate = t.TransactionDate.ToString("yyyy-MM-dd HH:mm"),
                                          cashierName = u != null ? u.FullName : t.IdUser,
                                          totalItem = _context.TrTransactionDetails.Where(d => d.IdTransaction == t.IdTransaction).Sum(d => (int?)d.Qty) ?? 0,
                                          paymentMethod = p != null ? p.MethodName : "-",
                                          totalPrice = t.TotalPrice
                                      })
                                      .Skip((page - 1) * pageSize)
                                      .Take(pageSize)
                                      .ToListAsync();

            return Ok(new
            {
                currentPage = page,
                totalPages = totalPages,
                totalData = totalData,
                data = transactions
            });
        }
    }

    public class TransactionSubmitDto
    {
        public string IdUser { get; set; }
        public int IdPaymentMethod { get; set; }
        public List<TransactionDetailDto> Details { get; set; }
    }

    public class TransactionDetailDto
    {
        public string IdProduct { get; set; }
        public int Qty { get; set; }
    }
}