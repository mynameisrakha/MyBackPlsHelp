﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BeeMart.API.Data;
using BeeMart.API.Models;

namespace BeeMart.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly BeeMartDbContext _context;
        private readonly PasswordHasher<MsUser> _passwordHasher = new PasswordHasher<MsUser>();

        public AuthController(BeeMartDbContext context)
        {
            _context = context;
        }

        // POST: api/Auth/register
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterDto model)
        {
            if (string.IsNullOrEmpty(model.Username) || string.IsNullOrEmpty(model.Password) ||
                string.IsNullOrEmpty(model.FullName) || string.IsNullOrEmpty(model.RePassword))
            {
                return BadRequest(new { message = "Semua field wajib diisi." });
            }

            if (model.Password != model.RePassword)
            {
                return BadRequest(new { message = "Password dan Re-Password tidak sama." });
            }

            // Validasi duplikasi username
            var existingUser = await _context.MsUsers.FirstOrDefaultAsync(u => u.Username == model.Username);
            if (existingUser != null)
            {
                return BadRequest(new { message = "Username already exists" });
            }

            // Generate IdUser otomatis (misal: US001)
            string lastId = await _context.MsUsers.OrderByDescending(u => u.IdUser).Select(u => u.IdUser).FirstOrDefaultAsync();
            int nextNumber = 1;
            if (!string.IsNullOrEmpty(lastId) && lastId.Length > 2 && int.TryParse(lastId.Substring(2), out int parsedNum))
            {
                nextNumber = parsedNum + 1;
            }
            string newIdUser = "US" + nextNumber.ToString("D3");

            var user = new MsUser
            {
                IdUser = newIdUser,
                Username = model.Username,
                FullName = model.FullName,
                Role = model.Role ?? "Cashier",
                Stsrc = true,
                Datein = DateTime.Now,
                Userin = "SYSTEM"
            };

            // Hashing password sebelum disimpan ke database
            user.PasswordHash = _passwordHasher.HashPassword(user, model.Password);

            _context.MsUsers.Add(user);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Registrasi berhasil", userId = user.IdUser });
        }

        // POST: api/Auth/login
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginDto model)
        {
            if (string.IsNullOrEmpty(model.Username) || string.IsNullOrEmpty(model.Password))
            {
                return BadRequest(new { message = "Invalid login" });
            }

            var user = await _context.MsUsers.FirstOrDefaultAsync(u => u.Username == model.Username && u.Role == model.Role);
            if (user == null)
            {
                return BadRequest(new { message = "Invalid login" });
            }

            // Verifikasi password yang di-hash
            var result = _passwordHasher.VerifyHashedPassword(user, user.PasswordHash, model.Password);
            if (result == PasswordVerificationResult.Failed)
            {
                return BadRequest(new { message = "Invalid login" });
            }

            return Ok(new
            {
                message = "Login berhasil",
                idUser = user.IdUser,
                username = user.Username,
                fullName = user.FullName,
                role = user.Role
            });
        }
    }

    public class RegisterDto
    {
        public string Username { get; set; }
        public string FullName { get; set; }
        public string Password { get; set; }
        public string RePassword { get; set; }
        public string Role { get; set; }
    }

    public class LoginDto
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
    }
}