﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Json;
using System.Text.Json;

namespace BeeMart.Web.Controllers
{
    // Bentuk data yang dikirim API setelah login berhasil
    public class LoginResult
    {
        public string? IdUser { get; set; }
        public string? Username { get; set; }
        public string? FullName { get; set; }
        public string? Role { get; set; }
    }

    public class AccountController : Controller
    {
        private readonly HttpClient _httpClient;

        public AccountController()
        {
            // Pastikan port disesuaikan dengan port API Anda (misal: 7088)
            var handler = new HttpClientHandler();
            handler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => true; // Mengabaikan warning SSL lokal
            _httpClient = new HttpClient(handler)
            {
                BaseAddress = new Uri("https://localhost:7088/api/")
            };
        }

        // ===================== LOGIN =====================

        [HttpGet]
        public IActionResult Login()
        {
            // Kalau sudah login, langsung ke halaman transaksi
            if (!string.IsNullOrEmpty(HttpContext.Session.GetString("IdUser")))
            {
                return RedirectToAction("Index", "Transaction");
            }
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(string username, string password, string role)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                ViewBag.Error = "Username dan Password wajib diisi.";
                return View();
            }

            var loginData = new
            {
                Username = username,
                Password = password,
                Role = role
            };

            try
            {
                // Mengirim request POST ke API backend Auth/login
                var response = await _httpClient.PostAsJsonAsync("Auth/login", loginData);

                if (response.IsSuccessStatusCode)
                {
                    // Ambil data user dari balasan API
                    var result = await response.Content.ReadFromJsonAsync<LoginResult>();

                    if (result == null || string.IsNullOrEmpty(result.IdUser))
                    {
                        ViewBag.Error = "Data login dari server tidak lengkap.";
                        return View();
                    }

                    // Simpan ke Session
                    HttpContext.Session.SetString("IdUser", result.IdUser);
                    HttpContext.Session.SetString("Username", result.Username ?? username);
                    HttpContext.Session.SetString("FullName", result.FullName ?? "");
                    HttpContext.Session.SetString("Role", result.Role ?? role);

                    return RedirectToAction("Index", "Transaction");
                }
                else
                {
                    ViewBag.Error = "Invalid login. Periksa kembali username, password, atau role Anda.";
                    return View();
                }
            }
            catch (Exception)
            {
                ViewBag.Error = "Tidak dapat terhubung ke server API backend.";
                return View();
            }
        }

        // ===================== LOGOUT =====================

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }

        // ===================== REGISTER =====================

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(string username, string fullName,
                                                  string password, string rePassword, string role)
        {
            // Supaya isian tidak hilang kalau ada error
            ViewBag.Username = username;
            ViewBag.FullName = fullName;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(fullName) ||
                string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(rePassword))
            {
                ViewBag.Error = "Username, Full Name, Password, dan Re-Password wajib diisi.";
                return View();
            }

            if (password != rePassword)
            {
                ViewBag.Error = "Password dan Re-Password tidak sama.";
                return View();
            }

            var registerData = new
            {
                Username = username,
                FullName = fullName,
                Password = password,
                RePassword = rePassword,
                Role = role
            };

            try
            {
                var response = await _httpClient.PostAsJsonAsync("Auth/register", registerData);

                if (response.IsSuccessStatusCode)
                {
                    TempData["Success"] = "Akun berhasil dibuat. Silakan login.";
                    return RedirectToAction("Login");
                }

                // Tampilkan pesan dari API, misalnya "username has already exists"
                ViewBag.Error = await ReadApiMessage(response, "Registrasi gagal. Periksa kembali data Anda.");
                return View();
            }
            catch (Exception)
            {
                ViewBag.Error = "Tidak dapat terhubung ke server API backend.";
                return View();
            }
        }

        // Mengambil isi "message" dari balasan JSON API
        private static async Task<string> ReadApiMessage(HttpResponseMessage response, string fallback)
        {
            try
            {
                var body = await response.Content.ReadAsStringAsync();
                using var doc = JsonDocument.Parse(body);
                if (doc.RootElement.TryGetProperty("message", out var msg))
                {
                    return msg.GetString() ?? fallback;
                }
            }
            catch
            {
                // abaikan, pakai pesan bawaan
            }
            return fallback;
        }
    }
}