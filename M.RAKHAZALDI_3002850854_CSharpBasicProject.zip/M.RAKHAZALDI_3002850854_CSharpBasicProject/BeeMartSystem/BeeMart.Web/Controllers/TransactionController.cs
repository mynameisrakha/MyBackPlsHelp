﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Json;

namespace BeeMart.Web.Controllers
{
    public class WebSubmitItem
    {
        public string IdProduct { get; set; } = "";
        public int Qty { get; set; }
    }

    public class WebSubmitRequest
    {
        public int IdPaymentMethod { get; set; }
        public List<WebSubmitItem> Details { get; set; } = new();
    }

    public class TransactionController : Controller
    {
        private readonly HttpClient _httpClient;

        public TransactionController()
        {
            var handler = new HttpClientHandler();
            handler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => true;
            _httpClient = new HttpClient(handler)
            {
                BaseAddress = new Uri("https://localhost:7088/api/")
            };
        }

        private bool IsLoggedIn => !string.IsNullOrEmpty(HttpContext.Session.GetString("IdUser"));

        public IActionResult Index()
        {
            if (!IsLoggedIn) return RedirectToAction("Login", "Account");
            return View();
        }

        // Meneruskan hasil API apa adanya ke browser
        private async Task<IActionResult> ToJson(HttpResponseMessage response)
        {
            var body = await response.Content.ReadAsStringAsync();
            return new ContentResult
            {
                Content = body,
                ContentType = "application/json",
                StatusCode = (int)response.StatusCode
            };
        }

        [HttpGet]
        public async Task<IActionResult> Search(string keyword)
        {
            if (!IsLoggedIn) return Unauthorized(new { message = "Sesi berakhir. Silakan login ulang." });
            try
            {
                var response = await _httpClient.GetAsync("MsProducts/search?keyword=" + Uri.EscapeDataString(keyword ?? ""));
                return await ToJson(response);
            }
            catch
            {
                return StatusCode(502, new { message = "Tidak dapat terhubung ke server API backend." });
            }
        }

        [HttpGet]
        public async Task<IActionResult> PaymentMethods()
        {
            if (!IsLoggedIn) return Unauthorized(new { message = "Sesi berakhir. Silakan login ulang." });
            try
            {
                var response = await _httpClient.GetAsync("LtPaymentMethods");
                return await ToJson(response);
            }
            catch
            {
                return StatusCode(502, new { message = "Tidak dapat terhubung ke server API backend." });
            }
        }

        [HttpGet]
        public async Task<IActionResult> NextInvoice()

        {
            if (!IsLoggedIn) return Unauthorized(new { message = "Sesi berakhir. Silakan login ulang." });
            try
            {
                var idUser = HttpContext.Session.GetString("IdUser");
                var response = await _httpClient.GetAsync("Transactions/next-invoice?idUser=" + Uri.EscapeDataString(idUser!));
                return await ToJson(response);
            }
            catch
            {
                return StatusCode(502, new { message = "Tidak dapat terhubung ke server API backend." });
            }
        }

        [HttpGet]
        public async Task<IActionResult> History(string? date, int page = 1)
        {
            if (!IsLoggedIn) return Unauthorized(new { message = "Sesi berakhir. Silakan login ulang." });

            if (string.IsNullOrWhiteSpace(date))
                return BadRequest(new { message = "Silakan pilih tanggal transaksi terlebih dahulu." });

            try
            {
                // IdUser & Role diambil dari Session (server), bukan dari browser
                var idUser = HttpContext.Session.GetString("IdUser") ?? "";
                var role = HttpContext.Session.GetString("Role") ?? "";

                var url = "Transactions/history"
                        + "?date=" + Uri.EscapeDataString(date)
                        + "&role=" + Uri.EscapeDataString(role)
                        + "&idUser=" + Uri.EscapeDataString(idUser)
                        + "&page=" + page;

                var response = await _httpClient.GetAsync(url);
                return await ToJson(response);
            }
            catch
            {
                return StatusCode(502, new { message = "Tidak dapat terhubung ke server API backend." });
            }
        }

        [HttpPost]
        public async Task<IActionResult> Submit([FromBody] WebSubmitRequest request)
        {
            if (!IsLoggedIn) return Unauthorized(new { message = "Sesi berakhir. Silakan login ulang." });
            try
            {
                // IdUser diambil dari Session, bukan dari browser
                var payload = new
                {
                    IdUser = HttpContext.Session.GetString("IdUser"),
                    IdPaymentMethod = request.IdPaymentMethod,
                    Details = request.Details
                };
                var response = await _httpClient.PostAsJsonAsync("Transactions/submit", payload);
                return await ToJson(response);
            }
            catch
            {
                return StatusCode(502, new { message = "Tidak dapat terhubung ke server API backend." });
            }
        }
    }
}