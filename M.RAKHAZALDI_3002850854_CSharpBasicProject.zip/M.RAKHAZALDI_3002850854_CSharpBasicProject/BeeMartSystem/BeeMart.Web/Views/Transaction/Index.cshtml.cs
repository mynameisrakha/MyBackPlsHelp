using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BeeMart.Web.Views.Transaction
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
