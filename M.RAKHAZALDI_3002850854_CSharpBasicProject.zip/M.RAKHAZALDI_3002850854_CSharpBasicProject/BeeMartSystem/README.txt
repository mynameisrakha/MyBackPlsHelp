Akun uji:
Admin -> username: admin, password: admin, role: Admin
Kasir -> username: kasir, password: kasir role: Kasir
